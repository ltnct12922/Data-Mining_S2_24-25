# Data-Mining_S2_24-25

## Dataset Information: https://www.kaggle.com/datasets/jmmvutu/summer-products-and-sales-in-ecommerce-wish

## Data Mining Project Report: https://docs.google.com/document/d/1O5zUOUZ-1OAdgt_6xIZhlMZipcce6L1XMjvDo7yNxus/edit?hl=vi&tab=t.0

## Members & Tasks: 
### Đinh Việt Anh: Pre-processing
### Lê Tinh Nhựt: Implement classification/prediction algorithms
### Nguyễn Trần Thiên Trí: Implement another algorithm
### Lê Công Thái Khang: Model Evaluation and Report
## How to Run:
### Click on Classification.java
### Run in terimnal: 
### javac -cp ".;lib/weka.jar" Classification.java (Output: Classification.java)
### java -cp ".;lib/weka.jar" Classification (Output: The result + .model files)
